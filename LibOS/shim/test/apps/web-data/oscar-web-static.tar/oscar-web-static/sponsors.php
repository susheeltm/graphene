

<html>

<head>
    <title>News | Operating System Security Concurrency and Architecture Research Lab</title>

    <link rel="StyleSheet" href="style.css" type="text/css">
    <link rel='Shortcut Icon' href="images/oscar-favicon.png" type="image/png">

</head>

<body>
    <script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-26854735-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
    <div class="wrapper">
        <div class="wrapper navigation">
           <div class="univ" style="background-image: url(images/sbu-logo-small.gif)">
               <a href="http://www.stonybrook.edu/" target="_blank">
                    <span>Stony Brook University</span>
               </a>
            </div>
            <div class="dept" style="background-image: url(images/cs-logo-small.gif)">
                <a href="http://www.cs.stonybrook.edu/" target="_blank">
                    <span>Computer Science Department</span>
                </a>
            </div>
        </div>

        <div class="wrapper">
            <div class="header" style="background-image: url(images/banner.jpg)">
            <a href="index.php">
                <div class="title">
                    <span class="l1"><b>O</b>perating System <b>S</b>ecurity <b>C</b>oncurrency<br/></span>
                    <span class="l2">and <b>A</b>rchitecture <b>R</b>esearch Lab</span>
                </div>
            </a>
            </div>
        </div>
    </div>

    <div class="content_wrapper">
        <div class="wrapper">

            <div class="gears">
                <div class="gear1" style="background-image: url(images/gear1.png)">
                    <p><a href="sponsors.php">Sponsors</a></p>
                </div>

                <div class="gear2" style="background-image: url(images/gear2.png)">
                    <p><a href="news.php">News</a></p>
                </div>
                <div class="gear3" style="background-image: url(images/gear2.png)">
                    <p><a href="people.php">People</a></p>
                </div>
                <div class="gear2" style="background-image: url(images/gear2.png)">
                    <p><a href="projects.php">Projects</a></p>
                </div>
                <div class="gear3" style="background-image: url(images/gear2.png)">
                    <p><a href="papers.php">Papers</a></p>
                </div>
            </div>

            <div class="content">
<!-- include_once /root/oscar-web/sponsors/sbu.php -->
<!-- content add Array
(
    [project] => Research Support Grant
    [name] => Stony Brook University, Office of the Vice President for Research
    [website] => http://www.stonybrook.edu
    [logo] => sponsors/logo/sbu.jpg
    [logo_width] => 127
    [logo_height] => 90
    [description] => 
)
 -->

<!-- include_once /root/oscar-web/sponsors/windriver.php -->
<!-- content add Array
(
    [project] => Simics Academic Site License
    [name] => Wind River
    [website] => http://www.windriver.com
    [logo] => 
    [logo_width] => 0
    [logo_height] => 0
    [description] => 
)
 -->

<!-- include_once /root/oscar-web/sponsors/example.php --><!-- include_once /root/oscar-web/sponsors/nsf_career.php -->
<!-- content add Array
(
    [project] => CAREER Award CNS-1149229
    [name] => National Science Foundation (NSF)
    [website] => http://www.nsf.gov
    [logo] => sponsors/logo/nsf.jpg
    [logo_width] => 186
    [logo_height] => 177
    [description] => 
)
 -->

<!-- include_once /root/oscar-web/sponsors/nsf_cloudtracker.php -->
<!-- content add Array
(
    [project] => Award CNS-1161541
    [name] => National Science Foundation (NSF)
    [website] => http://www.nsf.gov
    [logo] => sponsors/logo/nsf.jpg
    [logo_width] => 186
    [logo_height] => 177
    [description] => 
)
 -->


    <h3> Sponsors
            </h3>

    <h6>Our work will not be done without the generous support of our
    sponsors. It is our pleasure to work with our partners. We gratefully
    acknowkedge our sponsors as follows:</h6>

<div class="imagecloud"
 style="width:373 !important;
        height:197 !important;">
            <img src="sponsors/logo/nsf.jpg"
             style="position: absolute;
                    left:20;
                    top:10;
                    width:186;
                    height:177;" />
                    <img src="sponsors/logo/sbu.jpg"
             style="position: absolute;
                    left:226;
                    top:53.5;
                    width:127;
                    height:90;" />
        </div>
<div class="content_list">
    <div class="sponsors">
                    <div class="logo"><img src="sponsors/logo/nsf.jpg"></div>
        
                    <div class="organization">
                            <div class="name">National Science Foundation (NSF)</div>
            
                            <div class="project">Award CNS-1161541</div>
            
                            <div class="website">
                    <a href="http://www.nsf.gov">website</a>
                </div>
                        </div>
        
        
            </div>
    <div class="sponsors">
                    <div class="logo"><img src="sponsors/logo/nsf.jpg"></div>
        
                    <div class="organization">
                            <div class="name">National Science Foundation (NSF)</div>
            
                            <div class="project">CAREER Award CNS-1149229</div>
            
                            <div class="website">
                    <a href="http://www.nsf.gov">website</a>
                </div>
                        </div>
        
        
            </div>
    <div class="sponsors">
                    <div class="logo"><img src="sponsors/logo/sbu.jpg"></div>
        
                    <div class="organization">
                            <div class="name">Stony Brook University, Office of the Vice President for Research</div>
            
                            <div class="project">Research Support Grant</div>
            
                            <div class="website">
                    <a href="http://www.stonybrook.edu">website</a>
                </div>
                        </div>
        
        
            </div>
    <div class="sponsors">
        
                    <div class="organization">
                            <div class="name">Wind River</div>
            
                            <div class="project">Simics Academic Site License</div>
            
                            <div class="website">
                    <a href="http://www.windriver.com">website</a>
                </div>
                        </div>
        
        
            </div>
</div>
            </div>
        </div>
    </div>

    <div class="wrapper">
    </div>

    <div class="wrapper">
        <div class="labcontact">OSCAR Lab, Room 2203, Computer Science Building, Stony Brook University, Stony Brook, NY 11794-4400</div>
    </div>
</body>
</html>

