<?php

$nehal = array(
    "name"       => "Nehal Bandi",
    "title"      => "Masters Student, Computer Science, Stony Brook University",
    "office"     => "2203 Computer Science",
    "email"      => "nbandi@cs.stonybrook.edu",
    "website"    => "",
    "phone"      => "",
    "fax"        => "",
    "photo"      => "people/photos/nehal.jpg",
    
);

if (Content::InContentPage()) {
 
?>
<h3>History</h3>

<table style="border-width: 0">
<tr style="border-width: 0">
<td style="border-width: 0; padding: 0.3em">Fall '10 - <br/><i>(Graduate)</i></td>
<td style="border-width: 0; padding: 0.3em"><b>Stony Brook University</b><br/>M.S Candidate, Computer science<br/><a href="http://www.cs.stonybrook.edu" target="_blank">website</a></td>                              
</tr>

<tr style="border-width: 0">
<td style="border-width: 0; padding: 0.3em">Jan 2008-Aug 2010<br/><i>(Employment)</i></td>
<td style="border-width: 0; padding: 0.3em"><b>Atrenta Inc,India</b><br/>Lead Engineer<br/><a href="http://www.atrenta.com/" target="_blank">website</a></td>
</tr>

<tr style="border-width: 0">
<td style="border-width: 0; padding: 0.3em">July 2006-Jan 2008<br/><i>(Employment)</i></td>
<td style="border-width: 0; padding: 0.3em"><b>Siemens Ltd,India.</b><br/>Software Engineer<br/><a href="http://www.siemens.com/entry/in/en/" target="_blank">website</a></td>
</tr>

<tr style="border-width: 0">
<td style="border-width: 0; padding: 0.3em">2002 - 2006<br/><i>(Undergraduate)</i></td>
<td style="border-width: 0; padding: 0.3em"><b>Motilal Nehru National Institute Of Technology,India</b><br/>Bachelor of Science, computer science & Engineering<br/><a href="http://www.mnnit.ac.in" target="_blank">website</a></td>
</tr>
</table>


<?
}


Content::Add($nehal, 'bandi');

?>
