<?php

$xuan = array(
    "name"       => "Xuan Wang",
    "title"      => "Masters Student, Computer Science, Stony Brook University",
    "office"     => "2203 Computer Science",
    "email"      => "wang9@cs.stonybrook.edu",
    "website"    => "http://www.cs.stonybrook.edu/~wang9/",
    "phone"      => "",
    "fax"        => "",
    "photo"      => "people/photos/xuan.jpg",
    "alumnus"    => True,
);

#if (Content::InContentPage()) {
#
#}

Content::Add($xuan, "wang");
?>
