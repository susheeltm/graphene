<?php

$chiache = array(
    "name"       => "Chia-Che Tsai",
    "title"      => "Doctoral Student, Computer Science, Stony Brook University",
    "office"     => "2203 Computer Science",
    "email"      => "chitsai@cs.stonybrook.edu",
    "website"    => "http://www.cs.stonybrook.edu/~chitsai",
    "phone"      => "",
    "fax"        => "",
    "photo"      => "people/photos/chiache.jpg",
);

if (Content::InContentPage()) {
?>

<h3>History</h3>

<table style="border-width: 0">
<tr style="border-width: 0">
<td style="border-width: 0; padding: 0.3em"><b>Fall '11 - Now</b><br/><i>(Graduate)</i></td>
<td style="border-width: 0; padding: 0.3em"><b>Stony Brook University</b><br/>Ph.D Candidate, Computer science<br/><a href="http://www.cs.stonybrook.edu" target="_blank">website</a></td>                              
</tr>
<tr style="border-width: 0">
<td style="border-width: 0; padding: 0.3em">Spring '11 - Fall '11<br/><i>(Research Assistant)</i></td>
<td style="border-width: 0; padding: 0.3em"><b>Reliable System Lab</b><br/>Columbia University<br/><a href="http://rcs.cs.columbia.edu" target="_blank">website</a></td>                              
</tr>
<tr style="border-width: 0">
<td style="border-width: 0; padding: 0.3em">Fall '09 - Fall '10<br/><i>(Graduate)</i></td>
<td style="border-width: 0; padding: 0.3em"><b>Columbia University</b><br/>Master of Science, security track, computer science<br/><a href="http://www.cs.columbia.edu" target="_blank">website</a></td>                              
</tr>
<tr style="border-width: 0">
<td style="border-width: 0; padding: 0.3em">Fall '03 - Spring '07<br/><i>(Undergraduate)</i></td>
<td style="border-width: 0; padding: 0.3em"><b>National Taiwan University</b><br/>Bachelor of Science, computer science & information technology<br/><a href="http://www.csie.ntu.edu.tw" target="_blank">website</a></td>
<tr>
</tr></tr></table>

<h3>Publication</h3>

<ul>
<li style="margin-bottom: 2em"><b>Pervasive Detection of Process Races in Deployed Systems</b> [<a href="http://rcs.cs.columbia.edu/papers/racepro-sosp11.html">abstract</a> | <a href="http://rcs.cs.columbia.edu/papers/racepro-sosp11.pdf">pdf</a>]</b><br/>
Oren Laadan, Nicolas Viennot, <b>Chia-che Tsai</b>, and Chris Blinn, Junfeng Yang, Jason Nieh<br/>
Proceedings of the 23rd ACM Symposium on Operating Systems Principles (SOSP '11), 2011<br/></li>
<li style="margin-bottom: 2em"><b>Finding Concurrency Errors in Sequential Code---OS-level, In-vivo Model Checking of Process Races</b> [<a href="http://rcs.cs.columbia.edu/papers/racepro-hotos11.html">abstract</a> | <a href="http://rcs.cs.columbia.edu/papers/racepro-hotos11.pdf">pdf</a>]<br/>
Oren Laadan, <b>Chia-che Tsai</b>, Nicolas Viennot, Chris Blinn, Peter Senyao Du, Junfeng Yang, Jason Nieh<br/>
Proceedings of the 131th USENIX workshop on Hot topics in operating systems (HOTOS '11), 2011</li>
<li style="margin-bottom: 2em"><b>Stable Deterministic Multithreading through Schedule Memoization</b> [<a href="http://rcs.cs.columbia.edu/papers/cui-tern-osdi10.html">abstract</a> | <a href="http://rcs.cs.columbia.edu/papers/cui-tern-osdi10.pdf">pdf</a>]<br />
Heming Cui, Jingyue Wu, <b>Chia-Che Tsai</b>, Junfeng Yang<br />
Proceedings of the Ninth Symposium on Operating Systems Design and Implementation (OSDI '10), October, 2010</li>
</ul>

<?
}

Content::Add($chiache, 'tsai');

?>
