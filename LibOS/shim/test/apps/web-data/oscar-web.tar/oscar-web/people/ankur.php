<?php

$ankur = array(
    "name"       => "Ankur Agrawal",
    "title"      => "Master's Student, Computer Science, Stony Brook University",
    "office"     => "2203 Computer Science",
    "email"      => "anagrawal@cs.stonybrook.edu",
    "website"    => "",
    "phone"      => "",
    "fax"        => "",
    "photo"      => "people/photos/ankur.jpg",
);

## The following content will be shown in a individual page.
#
# if (Content::InContentPage()) {
# }

Content::Add($ankur, "agrawal");

?>
