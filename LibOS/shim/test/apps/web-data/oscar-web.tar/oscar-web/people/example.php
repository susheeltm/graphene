<?php

## Fill in the information
#

$new = array(
    "name"       => "",
    "title"      => "",
    "office"     => "",
    "email"      => "",
    "website"    => "",
    "phone"      => "",
    "fax"        => "",
    "photo"      => "",
);

## The following content will be shown in a individual page.
#
# if (Content::InContentPage()) {
# }

## Add it to the content.
#
# Content::Add($new, 0);

?>
