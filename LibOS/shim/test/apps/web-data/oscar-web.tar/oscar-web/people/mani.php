<?php

$mani = array(
    "name"       => "Manikantan Subramanian",
    "title"      => "Master's Student, Fall 2011, Computer Science, Stony Brook University",
    "office"     => "2203 Computer Science",
    "email"      => "masubramania@cs.stonybrook.edu",
    "website"    => "",
    "phone"      => "6316821834",
    "fax"        => "",
    "photo"      => "people/photos/mani.png",
);

## The following content will be shown in a individual page.
#
# if (Content::InContentPage()) {
# }

Content::Add($mani, "subramanian");

?>
