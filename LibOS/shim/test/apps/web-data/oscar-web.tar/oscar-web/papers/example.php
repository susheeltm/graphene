<?php

## Fill in the information
#

$new = array(
    "title"        => "",
    "publish"      => "",
    "publish_link" => "",
    "biblio"       => "",
    "format"       => array("pdf", ""),
);

## The following content will be shown in a individual page.
#
# if (Content::InContentPage()) {
# }

## Add it to the content.
#
# Content::Add($new, 0);

?>
