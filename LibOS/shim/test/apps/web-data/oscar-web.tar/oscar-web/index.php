<?php
# index.php
#
# Author: Chia-che Tsai
# Created: 09/08/2011
# Updated: 09/12/2011

define('PAGE_TITLE', 'Welcome');

define('SERVER_ROOT', dirname($_SERVER['SCRIPT_FILENAME']) . '/');
define('IN_SERVER', true);

include_once SERVER_ROOT . 'attribute.php';
include_once SERVER_ROOT . 'common.php';

include_once SERVER_ROOT . 'header.php';
?>

    <div id="welcome" style="background-image: url(<? echo URL_ROOT ?>images/welcome.png);">

        <p class="labname">
             <span class="l1"><b>O</b>perating System</span><br/>
             <span class="l2"><b>S</b>ecurity</span><br/>
             <span class="l3"><b>C</b>oncurrency</span><br/>
             <span class="l4">and <b>A</b>rchitecture</span><br/>
             <span class="l5"><b>R</b>esearch Lab</span>
        </p>

        <p class="deptname">
             <img class="logo" src="<? echo URL_ROOT ?>images/cs-logo.png">
             Computer Science, <br/>
             Stony Brook University
        </p>

        <div id="enter"><a href="<? echo URL_ROOT ?>news.php">ENTER</a></div>
    </div>
<?
include_once SERVER_ROOT . 'footer.php';
?>
