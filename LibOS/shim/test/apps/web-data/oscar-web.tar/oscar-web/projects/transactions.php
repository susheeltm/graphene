<?php

$trans = array(
    "title"        => "Operating System Transactions",
    "area"         => "Systems, Programming, Concurrency",
    "prerequisite" => "Experience with multi-threaded programming.  Formal methods experience a big plus.",
    "description"  => "We are exploring techniques to make multi-core computers easier to program, both in the OS and in applications.  Our work focuses on improved data structure and library designs that encapsulate this complexity from the programmer.",
);

#if (Content::InContentPage()) {
#}

Content::Add($trans, 0);

?>
