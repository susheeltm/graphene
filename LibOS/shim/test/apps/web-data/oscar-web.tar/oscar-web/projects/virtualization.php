<?php

$virt = array(
    "title"        => "Operating System Virtualization",
    "area"         => "Systems, Security",
    "prerequisite" => "C/C++/Assembly Programming, UNIX & Kernel Knowledge",
    "description"  => "Virtualization in operating systems is a technique to build virtual layers upon host systems to accommadate isolated systems. We are investigating novel virtualization techniques and applications of virtualization to improve the efficiency and utility of virtual machines.",
);

#if (Content::InContentPage()) {
#}

Content::Add($virt, 1);

?>
