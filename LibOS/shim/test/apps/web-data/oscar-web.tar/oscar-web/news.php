<?php
# news.php
#
# Author: Chia-che Tsai
# Created: 09/12/2011
# Updated: 09/12/2011


define('PAGE_TITLE', 'News');

define('SERVER_ROOT', dirname($_SERVER['SCRIPT_FILENAME']) . '/');
define('IN_SERVER', true);

include_once SERVER_ROOT . 'attribute.php';
include_once SERVER_ROOT . 'common.php';

define('PAGE_NAME', 'News');
define('PAGE_FILENAME', 'news.php');
define('CONTENT_TYPE', 'news');
define('REVERSE_SORT', true);

include_once SERVER_ROOT . 'common.main.php';
include_once SERVER_ROOT . 'header.main.php';
?>

<? if (!defined('CONTENT_PAGE')) { ?>
    <h6><b>OSCAR Lab</b> was founded in spring 2011 in Computer Science department, 
    Stony Brook University. We are working on research related issues in the areas 
    of Operating Systems, Virtualization, System Security, Concurrency and Computer 
    Architecture.</h6>
<? } ?>

    <h3> News
        <? if (defined('CONTENT_PAGE')) {
               $items = Content::Items();
               echo '> ' . $items[0]['title'];
           } ?>
    </h3>

<div class="content_list">
<? 
if (count(Content::Items()) <= 0) {
?>
    <h6> </h6>
<?
} else {
    foreach (Content::Items() as $item) { 
?>
    <div class="news">
        <? if ($item['title']) { ?>
            <div class="title"><? echo $item['title'] ?></div> 
        <? } ?>

        <? if ($item['date']) { ?>
            <div class="date">Posted: <? echo $item['date'] ?></div> 
        <? } ?>

        <? if ($item['description']) { ?>
            <div class="desc"><? echo $item['description'] ?></div>
        <? } ?>

        <? if (!defined('CONTENT_PAGE') && $item['page']) { ?> 
            <a class="readmore" href="<? echo URL_ROOT . PAGE_FILENAME . '?page=' . $item['page']?>">
                Read More
            </a>
        <? } ?>
    </div>
<?
    }
}
?>
</div>

<?php
include_once SERVER_ROOT . 'footer.main.php';
?>
