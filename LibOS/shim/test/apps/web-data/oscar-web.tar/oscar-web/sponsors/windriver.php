<?php

## Fill in the information
#

$simics = array(
    "project"     => "Simics Academic Site License",
    "name"        => "Wind River",
    "website"     => "http://www.windriver.com",
    "logo"        => "",
    "logo_width"  => 0,
    "logo_height" => 0,
    "description" => "",
);

## The following content will be shown in a individual page.
#
# if (Content::InContentPage()) {
# }

## Add it to the content.
#
Content::Add($simics, 1);

?>
