<?php
# common.php
#
# Author: Chia-che Tsai
# Created: 09/08/2011
# Updated: 09/12/2011

if (!defined('IN_SERVER')) {
    exit('Access Denied');
}

function hide_email_address($email) {
?>
        <script type="text/javascript">
        <!--
            var string1 = "<? echo substr($email, 0,
                                   strpos($email, '@')) ?>";
            var string2 = "@";
            var string3 = "<? echo substr($email,
                                   strpos($email, '@') + 1) ?>";
            var string4 = string1 + string2 + string3;
            document.write("<a href=" + "mail" + "to:" + 
                           string1 + string2 + string3 + ">" + 
                           string4 + "</a>");
        //-->
        </script>
<?
}

define('URL_ROOT', dirname('http://' . $_SERVER['HTTP_HOST'] . $_SERVER['SCRIPT_NAME']) . '/');

?>
