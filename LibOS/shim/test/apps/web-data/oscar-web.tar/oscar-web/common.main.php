<?php
# common.main.php
#
# Author: Chia-che Tsai
# Created: 09/10/2011
# Updated: 09/12/2011

if (!defined('IN_SERVER')) {
    exit('Access Denied');
}

class Content {
    private static $type = CONTENT_TYPE;
    private static $next_content_page = '';
    private static $add_content_page = FALSE;

    private static $keys = array();
    private static $vals = array();

    static function Add($val, $key = NULL) {
        echo "\n<!-- content add " . print_r($val, true) . " -->\n\n";

        if (defined('IN_CONTENT_PAGE')) return;

        if (self::$add_content_page) {
            $val['page'] = pathinfo(self::$next_content_page, PATHINFO_FILENAME);
            self::$add_content_page = FALSE;
        }

        self::$keys[] = $key;
        self::$vals[] = $val;
    }

    static function NextContentPage($page) {
        self::$next_content_page = $page;
    }

    static function InContentPage() {
        self::$add_content_page = TRUE;
        return defined('IN_CONTENT_PAGE');
    }

    static function Includable($page = NULL) {
        $dirs = array(self::$type);

        $scripts = array();

        foreach ($dirs as $dir) {
            $dir = SERVER_ROOT . $dir . '/';

            if ($handle = opendir($dir)) {

                while (false !== ($file = readdir($handle))) {
                    if (pathinfo($file, PATHINFO_EXTENSION) == 'php') {
                        if ($page) {
                            if (pathinfo($file, PATHINFO_FILENAME) == $page) {
                                define('CONTENT_PAGE', $dir . $file);
                                $scripts[] = $dir . $file;
                                break;
                            }
                        }
                        else {
                            $scripts[] = $dir . $file;
                        }
                    }
                }

                closedir($handle);
            }
        }

        return $scripts;
    }

    static function Sort($desc = FALSE) {
        if ($desc)
            array_multisort(self::$keys, SORT_DESC, self::$vals);
        else
            array_multisort(self::$keys, self::$vals);
    }

    static function Items() {
        return self::$vals;
    }
}
?>

