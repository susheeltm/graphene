<?php
# projects.php
#
# Author: Chia-che Tsai
# Created: 09/12/2011
# Updated: 09/12/2011

define('PAGE_TITLE', 'Projects');

define('SERVER_ROOT', dirname($_SERVER['SCRIPT_FILENAME']) . '/');
define('IN_SERVER', true);

include_once SERVER_ROOT . 'attribute.php';
include_once SERVER_ROOT . 'common.php';

define('PAGE_NAME', 'Projects');
define('PAGE_FILENAME', 'projects.php');
define('CONTENT_TYPE', 'projects');

include_once SERVER_ROOT . 'common.main.php';
include_once SERVER_ROOT . 'header.main.php';
?>

    <h1>
        Projects
        <? if (defined('CONTENT_PAGE')) {
               $items = Content::Items();
               echo '> ' . $items[0]['title'];
           } ?>
    </h1>

<? if (!defined('CONTENT_PAGE')) { ?>
    <h6>We are looking for outstanding, enthusiastic students 
    to join our lab.  Several ongoing projects are listed below.
    If you are interested in joining the lab, the best way to 
    begin is to take a systems course with Professor Porter or 
    otherwise get to know the lab members.
    </h6>

    <h6>If you are considering applying to Stony Brook, 
    we encourage you to apply to the department.  Please note
    that you must be admitted to the department before you can join 
    our lab, and that we cannot pre-admit any students.
    </h6>

<? } ?>


<div class="content_list">
<? 
foreach (Content::Items() as $item) { 
?>
    <div class="projects">
        <? if ($item['title']) { ?>
            <div class="title"><? echo $item['title'] ?></div> 
        <? } ?>

        <? if ($item['area']) { ?>
            <div class="area">Related Areas: <? echo $item['area'] ?></div> 
        <? } ?>

        <? if ($item['prerequisite']) { ?>
            <div class="prereq">Prerequisite: <? echo $item['prerequisite'] ?></div>
        <? } ?>

        <? if ($item['description']) { ?>
            <div class="desc"><? echo $item['description'] ?></div>
        <? } ?>

        <? if (!defined('CONTENT_PAGE') && $item['page']) { ?> 
            <a class="readmore" href="<? echo URL_ROOT . PAGE_FILENAME . '?page=' . $item['page']?>">
                Read More
            </a>
        <? } ?>
    </div>
<?
}
?>
</div>

<?php
include_once SERVER_ROOT . 'footer.main.php';
?>
