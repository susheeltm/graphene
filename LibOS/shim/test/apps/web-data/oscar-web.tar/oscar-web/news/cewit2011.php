<?php

## Fill in the information
#

$new = array(
    "date"        => "10/21/2011",
    "title"       => "Three Posters accepted in CEWIT Conference 2011",
    "description" => "CEWIT 2011 - The 8th International Conference & Expo on Emerging Technologies 
for a Smarter World. <br/><a href=\"http://www.cewit.org/conference2011\">http://www.cewit.org/conference2011</a>",
);

## The following content will be shown in a individual page.
#
#if (Content::InContentPage()) {
#}

## Add it to the content.
#
Content::Add($new, "20111021");

?>
