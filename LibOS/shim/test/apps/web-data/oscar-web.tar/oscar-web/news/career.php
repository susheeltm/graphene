<?php

## Fill in the information
#

$new = array(
    "date"        => "12/22/11",
    "title"       => "Professor Porter awarded NSF CAREER grant",
    "description" => "<a href=\"http://www.nsf.gov/awardsearch/showAward.do?AwardNumber=1149229\">CAREER: Beyond Virtual Hardware: VMM/OS Co-Design for Lightweight, Flexible Virtualization.</a><br/>

Read the university press release <a href=\"http://www.cs.stonybrook.edu/about/news/donPorterNSF2012.html\">here.</a><br/>

This award also generated <a href=\"http://www.northshoreoflongisland.com/Articles-Arts-and-Lifestyles-i-2012-04-19-92067.112114-SBU-professors-goal-to-demystify-the-computer.html\">a nice story</a> about the lab in the local newspaper.
");

## The following content will be shown in a individual page.
#
# if (Content::InContentPage()) {
# }

## Add it to the content.
#
Content::Add($new, "20111222");

?>
