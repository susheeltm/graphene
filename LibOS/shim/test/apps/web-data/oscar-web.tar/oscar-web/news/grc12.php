<?php

## Fill in the information
#

$new = array(
    "date"        => "3/30/12",
    "title"       => "OSCAR wins the GRC Lab Cup",
    "description" => "At the <a href=\"http://www.cs.stonybrook.edu/~grc/\">2012 Stony Brook CS Graduate Research Conference (GRC Day)</a>, OSCAR lab won the lab cup.  Don Porter also won the Most Supportive Professor Award.",
);

## The following content will be shown in a individual page.
#
# if (Content::InContentPage()) {
# }

## Add it to the content.
#
Content::Add($new, "20120330");

?>
