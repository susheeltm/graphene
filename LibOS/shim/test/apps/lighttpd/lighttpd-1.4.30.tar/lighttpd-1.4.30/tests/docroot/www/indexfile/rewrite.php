<?php
	print $_SERVER["QUERY_STRING"];
?>
